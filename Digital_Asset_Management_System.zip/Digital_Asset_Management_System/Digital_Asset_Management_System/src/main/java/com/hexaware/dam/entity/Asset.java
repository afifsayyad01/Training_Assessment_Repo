package com.hexaware.dam.entity;

import java.util.Date;

public class Asset {
    private int assetId;
    private String name;
    private String type;
    private String serialNumber;
    private Date purchaseDate;
    private String location;
    private String status;
    private Integer ownerId;  // Using Integer to allow null values

    // Default constructor
    public Asset() {
    }

    // Parameterized constructor
    public Asset(int assetId, String name, String type, String serialNumber, Date purchaseDate,
                 String location, String status, Integer ownerId) {
        this.assetId = assetId;
        this.name = name;
        this.type = type;
        this.serialNumber = serialNumber;
        this.purchaseDate = purchaseDate;
        this.location = location;
        this.status = status;
        this.ownerId = ownerId;
    }

    // Constructor without ID (for inserting new assets)
    public Asset(String name, String type, String serialNumber, Date purchaseDate,
                 String location, String status, Integer ownerId) {
        this.name = name;
        this.type = type;
        this.serialNumber = serialNumber;
        this.purchaseDate = purchaseDate;
        this.location = location;
        this.status = status;
        this.ownerId = ownerId;
    }

    // Getters and Setters
    public int getAssetId() {
        return assetId;
    }

    public void setAssetId(int assetId) {
        this.assetId = assetId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getSerialNumber() {
        return serialNumber;
    }

    public void setSerialNumber(String serialNumber) {
        this.serialNumber = serialNumber;
    }

    public Date getPurchaseDate() {
        return purchaseDate;
    }

    public void setPurchaseDate(Date purchaseDate) {
        this.purchaseDate = purchaseDate;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Integer getOwnerId() {
        return ownerId;
    }

    public void setOwnerId(Integer ownerId) {
        this.ownerId = ownerId;
    }

    @Override
    public String toString() {
        return "Asset{" +
                "assetId=" + assetId +
                ", name='" + name + '\'' +
                ", type='" + type + '\'' +
                ", serialNumber='" + serialNumber + '\'' +
                ", purchaseDate=" + purchaseDate +
                ", location='" + location + '\'' +
                ", status='" + status + '\'' +
                ", ownerId=" + ownerId +
                '}';
    }
}