package com.hexaware.dam.exception;

public class AssetNotFoundException extends Exception {

    public AssetNotFoundException() {
        super("Asset ID not found!");
    }

    public AssetNotFoundException(String message) {
        super(message);
    }
}