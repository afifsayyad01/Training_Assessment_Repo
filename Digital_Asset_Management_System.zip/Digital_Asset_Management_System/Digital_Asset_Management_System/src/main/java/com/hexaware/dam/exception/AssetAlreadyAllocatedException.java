package com.hexaware.dam.exception;

public class AssetAlreadyAllocatedException extends Exception {

    public AssetAlreadyAllocatedException() {
        super("Asset is already allocated to an employee!");
    }

    public AssetAlreadyAllocatedException(String message) {
        super(message);
    }
}