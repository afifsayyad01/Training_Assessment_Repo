package com.hexaware.dam.dao;

import com.hexaware.dam.entity.*;
import com.hexaware.dam.exception.*;
import com.hexaware.dam.util.DBConnUtil;
import com.hexaware.dam.util.DBPropertyUtil;

import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class AssetManagementServiceImpl implements AssetManagementService {

    private Connection connection;
    private SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

    public AssetManagementServiceImpl() {
        connection = DBConnUtil.getConnection(DBPropertyUtil.getConnectionString("db.properties"));
    }

    @Override
    public boolean addAsset(Asset asset) throws Exception {
        String sql = "INSERT INTO assets (name, type, serial_number, purchase_date, location, status, owner_id) VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, asset.getName());
            statement.setString(2, asset.getType());
            statement.setString(3, asset.getSerialNumber());
            statement.setDate(4, new java.sql.Date(asset.getPurchaseDate().getTime()));
            statement.setString(5, asset.getLocation());
            statement.setString(6, asset.getStatus());

            if (asset.getOwnerId() != null) {
                statement.setInt(7, asset.getOwnerId());
            } else {
                statement.setNull(7, Types.INTEGER);
            }

            int rowsAffected = statement.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            throw new Exception("Error adding asset: " + e.getMessage());
        }
    }

    @Override
    public boolean updateAsset(Asset asset) throws AssetNotFoundException {
        if (!checkIfAssetExists(asset.getAssetId())) {
            throw new AssetNotFoundException("Asset with ID " + asset.getAssetId() + " not found");
        }

        String sql = "UPDATE assets SET name = ?, type = ?, serial_number = ?, purchase_date = ?, " +
                "location = ?, status = ?, owner_id = ? WHERE asset_id = ?";

        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, asset.getName());
            statement.setString(2, asset.getType());
            statement.setString(3, asset.getSerialNumber());
            statement.setDate(4, new java.sql.Date(asset.getPurchaseDate().getTime()));
            statement.setString(5, asset.getLocation());
            statement.setString(6, asset.getStatus());

            if (asset.getOwnerId() != null) {
                statement.setInt(7, asset.getOwnerId());
            } else {
                statement.setNull(7, Types.INTEGER);
            }

            statement.setInt(8, asset.getAssetId());

            int rowsAffected = statement.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            System.err.println("Error updating asset: " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean deleteAsset(int assetId) throws AssetNotFoundException {
        if (!checkIfAssetExists(assetId)) {
            throw new AssetNotFoundException("Asset with ID " + assetId + " not found");
        }

        // First check if the asset is allocated or reserved
        String checkSql = "SELECT COUNT(*) FROM asset_allocations WHERE asset_id = ? AND return_date IS NULL";

        try (PreparedStatement statement = connection.prepareStatement(checkSql)) {
            statement.setInt(1, assetId);
            ResultSet rs = statement.executeQuery();

            if (rs.next() && rs.getInt(1) > 0) {
                System.out.println("Cannot delete asset because it is currently allocated");
                return false;
            }

            String deleteSql = "DELETE FROM assets WHERE asset_id = ?";

            try (PreparedStatement deleteStatement = connection.prepareStatement(deleteSql)) {
                deleteStatement.setInt(1, assetId);
                int rowsAffected = deleteStatement.executeUpdate();
                return rowsAffected > 0;
            }
        } catch (SQLException e) {
            System.err.println("Error deleting asset: " + e.getMessage());
            return false;
        }
    }

    @Override
    public Asset getAssetById(int assetId) throws AssetNotFoundException {
        String sql = "SELECT * FROM assets WHERE asset_id = ?";

        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, assetId);
            ResultSet rs = statement.executeQuery();

            if (rs.next()) {
                Asset asset = new Asset();
                asset.setAssetId(rs.getInt("asset_id"));
                asset.setName(rs.getString("name"));
                asset.setType(rs.getString("type"));
                asset.setSerialNumber(rs.getString("serial_number"));
                asset.setPurchaseDate(rs.getDate("purchase_date"));
                asset.setLocation(rs.getString("location"));
                asset.setStatus(rs.getString("status"));

                int ownerId = rs.getInt("owner_id");
                if (!rs.wasNull()) {
                    asset.setOwnerId(ownerId);
                }

                return asset;
            } else {
                throw new AssetNotFoundException("Asset with ID " + assetId + " not found");
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving asset: " + e.getMessage());
            throw new AssetNotFoundException("Error retrieving asset: " + e.getMessage());
        }
    }

    @Override
    public boolean allocateAsset(int assetId, int employeeId, String allocationDate)
            throws AssetNotFoundException, EmployeeNotFoundException, AssetAlreadyAllocatedException {

        if (!checkIfAssetExists(assetId)) {
            throw new AssetNotFoundException("Asset with ID " + assetId + " not found");
        }

        if (!checkIfEmployeeExists(employeeId)) {
            throw new EmployeeNotFoundException("Employee with ID " + employeeId + " not found");
        }

        // Check if asset is already allocated
        String checkSql = "SELECT COUNT(*) FROM asset_allocations WHERE asset_id = ? AND return_date IS NULL";

        try (PreparedStatement statement = connection.prepareStatement(checkSql)) {
            statement.setInt(1, assetId);
            ResultSet rs = statement.executeQuery();

            if (rs.next() && rs.getInt(1) > 0) {
                throw new AssetAlreadyAllocatedException("Asset is already allocated to an employee");
            }

            // Insert new allocation
            String insertSql = "INSERT INTO asset_allocations (asset_id, employee_id, allocation_date) VALUES (?, ?, ?)";

            try (PreparedStatement insertStatement = connection.prepareStatement(insertSql)) {
                insertStatement.setInt(1, assetId);
                insertStatement.setInt(2, employeeId);

                Date date = dateFormat.parse(allocationDate);
                insertStatement.setDate(3, new java.sql.Date(date.getTime()));

                int rowsAffected = insertStatement.executeUpdate();

                if (rowsAffected > 0) {
                    // Update asset status and owner
                    String updateSql = "UPDATE assets SET status = 'In Use', owner_id = ? WHERE asset_id = ?";

                    try (PreparedStatement updateStatement = connection.prepareStatement(updateSql)) {
                        updateStatement.setInt(1, employeeId);
                        updateStatement.setInt(2, assetId);
                        updateStatement.executeUpdate();
                    }

                    return true;
                }

                return false;
            }
        } catch (SQLException | ParseException e) {
            System.err.println("Error allocating asset: " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean deallocateAsset(int assetId, int employeeId, String returnDate)
            throws AssetNotFoundException, EmployeeNotFoundException {

        if (!checkIfAssetExists(assetId)) {
            throw new AssetNotFoundException("Asset with ID " + assetId + " not found");
        }

        if (!checkIfEmployeeExists(employeeId)) {
            throw new EmployeeNotFoundException("Employee with ID " + employeeId + " not found");
        }

        String sql = "UPDATE asset_allocations SET return_date = ? " +
                "WHERE asset_id = ? AND employee_id = ? AND return_date IS NULL";

        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            Date date = dateFormat.parse(returnDate);
            statement.setDate(1, new java.sql.Date(date.getTime()));
            statement.setInt(2, assetId);
            statement.setInt(3, employeeId);

            int rowsAffected = statement.executeUpdate();

            if (rowsAffected > 0) {
                // Update asset status and owner
                String updateSql = "UPDATE assets SET status = 'Available', owner_id = NULL WHERE asset_id = ?";

                try (PreparedStatement updateStatement = connection.prepareStatement(updateSql)) {
                    updateStatement.setInt(1, assetId);
                    updateStatement.executeUpdate();
                }

                return true;
            }

            return false;
        } catch (SQLException | ParseException e) {
            System.err.println("Error deallocating asset: " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean performMaintenance(int assetId, String maintenanceDate, String description, double cost)
            throws AssetNotFoundException {

        if (!checkIfAssetExists(assetId)) {
            throw new AssetNotFoundException("Asset with ID " + assetId + " not found");
        }

        String sql = "INSERT INTO maintenance_records (asset_id, maintenance_date, description, cost) " +
                "VALUES (?, ?, ?, ?)";

        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, assetId);

            Date date = dateFormat.parse(maintenanceDate);
            statement.setDate(2, new java.sql.Date(date.getTime()));
            statement.setString(3, description);
            statement.setDouble(4, cost);

            int rowsAffected = statement.executeUpdate();

            if (rowsAffected > 0) {
                // Update asset status
                String updateSql = "UPDATE assets SET status = 'Maintained' WHERE asset_id = ?";

                try (PreparedStatement updateStatement = connection.prepareStatement(updateSql)) {
                    updateStatement.setInt(1, assetId);
                    updateStatement.executeUpdate();
                }

                return true;
            }

            return false;
        } catch (SQLException | ParseException e) {
            System.err.println("Error performing maintenance: " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean reserveAsset(int assetId, int employeeId, String reservationDate, String startDate, String endDate)
            throws AssetNotFoundException, EmployeeNotFoundException, AssetNotMaintainException {

        if (!checkIfAssetExists(assetId)) {
            throw new AssetNotFoundException("Asset with ID " + assetId + " not found");
        }

        if (!checkIfEmployeeExists(employeeId)) {
            throw new EmployeeNotFoundException("Employee with ID " + employeeId + " not found");
        }

        // Check if asset has been maintained in the last 2 years
        if (!checkAssetMaintenance(assetId)) {
            throw new AssetNotMaintainException("Asset has not been maintained for 2 years");
        }

        String sql = "INSERT INTO reservations (asset_id, employee_id, reservation_date, start_date, end_date, status) " +
                "VALUES (?, ?, ?, ?, ?, 'Pending')";

        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, assetId);
            statement.setInt(2, employeeId);

            Date resDate = dateFormat.parse(reservationDate);
            Date sDate = dateFormat.parse(startDate);
            Date eDate = dateFormat.parse(endDate);

            statement.setDate(3, new java.sql.Date(resDate.getTime()));
            statement.setDate(4, new java.sql.Date(sDate.getTime()));
            statement.setDate(5, new java.sql.Date(eDate.getTime()));

            int rowsAffected = statement.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException | ParseException e) {
            System.err.println("Error reserving asset: " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean withdrawReservation() throws ReservationNotFoundException {
        int reservationId = 0;
        if (!checkIfReservationExists(reservationId)) {
            throw new ReservationNotFoundException("Reservation with ID " + reservationId + " not found");
        }

        String sql = "UPDATE reservations SET status = 'Cancelled' WHERE reservation_id = ?";

        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, reservationId);

            int rowsAffected = statement.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            System.err.println("Error withdrawing reservation: " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean checkIfAssetExists(int assetId) {
        String sql = "SELECT COUNT(*) FROM assets WHERE asset_id = ?";

        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, assetId);
            ResultSet rs = statement.executeQuery();

            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            System.err.println("Error checking if asset exists: " + e.getMessage());
        }

        return false;
    }

    @Override
    public boolean checkIfEmployeeExists(int employeeId) {
        String sql = "SELECT COUNT(*) FROM employees WHERE employee_id = ?";

        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, employeeId);
            ResultSet rs = statement.executeQuery();

            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            System.err.println("Error checking if employee exists: " + e.getMessage());
        }

        return false;
    }

    @Override
    public boolean checkIfReservationExists(int reservationId) {
        String sql = "SELECT COUNT(*) FROM reservations WHERE reservation_id = ?";

        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, reservationId);
            ResultSet rs = statement.executeQuery();

            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            System.err.println("Error checking if reservation exists: " + e.getMessage());
        }

        return false;
    }

    @Override
    public boolean checkAssetMaintenance(int assetId) throws AssetNotFoundException {
        if (!checkIfAssetExists(assetId)) {
            throw new AssetNotFoundException("Asset with ID " + assetId + " not found");
        }

        String sql = "SELECT MAX(maintenance_date) FROM maintenance_records WHERE asset_id = ?";

        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, assetId);
            ResultSet rs = statement.executeQuery();

            if (rs.next()) {
                Date lastMaintenanceDate = rs.getDate(1);

                if (lastMaintenanceDate == null) {
                    // If there's no maintenance record, check purchase date
                    String purchaseSql = "SELECT purchase_date FROM assets WHERE asset_id = ?";

                    try (PreparedStatement purchaseStatement = connection.prepareStatement(purchaseSql)) {
                        purchaseStatement.setInt(1, assetId);
                        ResultSet purchaseRs = purchaseStatement.executeQuery();

                        if (purchaseRs.next()) {
                            Date purchaseDate = purchaseRs.getDate(1);

                            // If purchased within 2 years, it's ok
                            Calendar calendar = Calendar.getInstance();
                            calendar.add(Calendar.YEAR, -2);
                            Date twoYearsAgo = calendar.getTime();

                            return purchaseDate.after(twoYearsAgo);
                        }
                    }

                    return false;
                }

                // Check if maintenance was within 2 years
                Calendar calendar = Calendar.getInstance();
                calendar.add(Calendar.YEAR, -2);
                Date twoYearsAgo = calendar.getTime();

                return lastMaintenanceDate.after(twoYearsAgo);
            }
        } catch (SQLException e) {
            System.err.println("Error checking asset maintenance: " + e.getMessage());
        }

        return false;
    }

    @Override
    public void reserveAsset() {

    }
}