package com.hexaware.dam.exception;

public class ReservationNotFoundException extends Exception {

    public ReservationNotFoundException() {
        super("Reservation ID not found!");
    }

    public ReservationNotFoundException(String message) {
        super(message);
    }
}