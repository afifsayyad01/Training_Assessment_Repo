package com.hexaware.dam.util;

import java.io.InputStream;
import java.util.Properties;

public class DBPropertyUtil {

    public static String getConnectionString(String propertyFileName) {
        Properties properties = new Properties();
        String connectionString = null;

        try (InputStream inputStream = DBPropertyUtil.class.getClassLoader().getResourceAsStream(propertyFileName)) {
            if (inputStream == null) {
                System.err.println("Unable to find " + propertyFileName);
                return null;
            }

            properties.load(inputStream);

            String url = properties.getProperty("db.url");
            String username = properties.getProperty("db.username");
            String password = properties.getProperty("db.password");

            connectionString = url + "?user=" + username + "&password=" + password;

        } catch (Exception e) {
            System.err.println("Error loading database properties: " + e.getMessage());
        }

        return connectionString;
    }
}