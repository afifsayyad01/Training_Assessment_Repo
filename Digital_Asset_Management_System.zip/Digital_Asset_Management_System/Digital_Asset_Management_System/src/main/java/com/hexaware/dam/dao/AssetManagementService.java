package com.hexaware.dam.dao;

import com.hexaware.dam.entity.*;
import com.hexaware.dam.exception.*;

public interface AssetManagementService {

    // Asset Management
    boolean addAsset(Asset asset) throws Exception;
    boolean updateAsset(Asset asset) throws AssetNotFoundException;
    boolean deleteAsset(int assetId) throws AssetNotFoundException;
    Asset getAssetById(int assetId) throws AssetNotFoundException;

    // Asset Allocation
    boolean allocateAsset(int assetId, int employeeId, String allocationDate)
            throws AssetNotFoundException, EmployeeNotFoundException, AssetAlreadyAllocatedException;
    boolean deallocateAsset(int assetId, int employeeId, String returnDate)
            throws AssetNotFoundException, EmployeeNotFoundException;

    // Asset Maintenance
    boolean performMaintenance(int assetId, String maintenanceDate, String description, double cost)
            throws AssetNotFoundException;

    // Asset Reservation
    boolean reserveAsset(int assetId, int employeeId, String reservationDate, String startDate, String endDate)
            throws AssetNotFoundException, EmployeeNotFoundException, AssetNotMaintainException;
    boolean withdrawReservation()
            throws ReservationNotFoundException;

    // Additional utility methods
    boolean checkIfAssetExists(int assetId);
    boolean checkIfEmployeeExists(int employeeId);
    boolean checkIfReservationExists(int reservationId);
    boolean checkAssetMaintenance(int assetId) throws AssetNotFoundException;

    void reserveAsset();
}