package com.hexaware.dam.main;

import com.hexaware.dam.dao.AssetManagementService;
import com.hexaware.dam.dao.AssetManagementServiceImpl;
import com.hexaware.dam.entity.Asset;
import com.hexaware.dam.exception.*;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class MainModule {

    private static AssetManagementService service = new AssetManagementServiceImpl();
    private static Scanner scanner = new Scanner(System.in);
    private static SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

    public static void main(String[] args) {
        boolean running = true;

        while (running) {
            displayMenu();

            int choice;
            try {
                System.out.print("\nEnter your choice: ");
                choice = Integer.parseInt(scanner.nextLine());

                switch (choice) {
                    case 1:
                        addAsset();
                        break;
                    case 2:
                        updateAsset();
                        break;
                    case 3:
                        deleteAsset();
                        break;
                    case 4:
                        allocateAsset();
                        break;
                    case 5:
                        deallocateAsset();
                        break;
                    case 6:
                        performMaintenance();
                        break;
                    case 7:
                        service.reserveAsset();
                        break;
                    case 8:
                        service.withdrawReservation();
                        break;
                    case 9:
                        running = false;
                        System.out.println("Thank you for using Digital Asset Management System. Goodbye!");
                        break;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number.");
            } catch (ReservationNotFoundException e) {
                throw new RuntimeException(e);
            }

            System.out.println("\nPress Enter to continue...");
            scanner.nextLine();
        }
    }

    private static void displayMenu() {
        System.out.println("\n===== Digital Asset Management System =====");
        System.out.println("1. Add Asset");
        System.out.println("2. Update Asset");
        System.out.println("3. Delete Asset");
        System.out.println("4. Allocate Asset");
        System.out.println("5. Deallocate Asset");
        System.out.println("6. Perform Maintenance");
        System.out.println("7. Reserve Asset");
        System.out.println("8. Withdraw Reservation");
        System.out.println("9. Exit");
    }

    private static void addAsset() {
        try {
            System.out.println("\n----- Add New Asset -----");

            System.out.print("Enter asset name: ");
            String name = scanner.nextLine();

            System.out.print("Enter asset type: ");
            String type = scanner.nextLine();

            System.out.print("Enter serial number: ");
            String serialNumber = scanner.nextLine();

            System.out.print("Enter purchase date (yyyy-MM-dd): ");
            String purchaseDateStr = scanner.nextLine();
            Date purchaseDate = dateFormat.parse(purchaseDateStr);

            System.out.print("Enter location: ");
            String location = scanner.nextLine();

            System.out.print("Enter status: ");
            String status = scanner.nextLine();

            System.out.print("Enter owner ID (or 0 for none): ");
            int ownerId = Integer.parseInt(scanner.nextLine());

            Asset asset = new Asset();
            asset.setName(name);
            asset.setType(type);
            asset.setSerialNumber(serialNumber);
            asset.setPurchaseDate(purchaseDate);
            asset.setLocation(location);
            asset.setStatus(status);

            if (ownerId > 0) {
                asset.setOwnerId(ownerId);
            }

            boolean result = service.addAsset(asset);
            if (result) {
                System.out.println("Asset added successfully!");
            } else {
                System.out.println("Failed to add asset.");
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void updateAsset() {
        try {
            System.out.println("\n----- Update Asset -----");

            System.out.print("Enter asset ID to update: ");
            int assetId = Integer.parseInt(scanner.nextLine());

            try {
                Asset asset = service.getAssetById(assetId);

                System.out.println("Current asset details:");
                System.out.println(asset);

                System.out.print("Enter new name (press Enter to keep current): ");
                String name = scanner.nextLine();
                if (!name.isEmpty()) {
                    asset.setName(name);
                }

                System.out.print("Enter new type (press Enter to keep current): ");
                String type = scanner.nextLine();
                if (!type.isEmpty()) {
                    asset.setType(type);
                }

                System.out.print("Enter new serial number (press Enter to keep current): ");
                String serialNumber = scanner.nextLine();
                if (!serialNumber.isEmpty()) {
                    asset.setSerialNumber(serialNumber);
                }

                System.out.print("Enter new purchase date (yyyy-MM-dd) (press Enter to keep current): ");
                String purchaseDateStr = scanner.nextLine();
                if (!purchaseDateStr.isEmpty()) {
                    Date purchaseDate = dateFormat.parse(purchaseDateStr);
                    asset.setPurchaseDate(purchaseDate);
                }

                System.out.print("Enter new location (press Enter to keep current): ");
                String location = scanner.nextLine();
                if (!location.isEmpty()) {
                    asset.setLocation(location);
                }

                System.out.print("Enter new status (press Enter to keep current): ");
                String status = scanner.nextLine();
                if (!status.isEmpty()) {
                    asset.setStatus(status);
                }

                System.out.print("Enter new owner ID (0 for none, press Enter to keep current): ");
                String ownerIdStr = scanner.nextLine();
                if (!ownerIdStr.isEmpty()) {
                    int ownerId = Integer.parseInt(ownerIdStr);
                    if (ownerId > 0) {
                        asset.setOwnerId(ownerId);
                    } else {
                        asset.setOwnerId(null);
                    }
                }

                boolean result = service.updateAsset(asset);
                if (result) {
                    System.out.println("Asset updated successfully!");
                } else {
                    System.out.println("Failed to update asset.");
                }

            } catch (AssetNotFoundException e) {
                System.out.println("Error: " + e.getMessage());
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void deleteAsset() {
        try {
            System.out.println("\n----- Delete Asset -----");

            System.out.print("Enter asset ID to delete: ");
            int assetId = Integer.parseInt(scanner.nextLine());

            try {
                boolean result = service.deleteAsset(assetId);
                if (result) {
                    System.out.println("Asset deleted successfully!");
                } else {
                    System.out.println("Failed to delete asset. It may be currently allocated.");
                }
            } catch (AssetNotFoundException e) {
                System.out.println("Error: " + e.getMessage());
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void allocateAsset() {
        try {
            System.out.println("\n----- Allocate Asset -----");

            System.out.print("Enter asset ID: ");
            int assetId = Integer.parseInt(scanner.nextLine());

            System.out.print("Enter employee ID: ");
            int employeeId = Integer.parseInt(scanner.nextLine());

            System.out.print("Enter allocation date (yyyy-MM-dd): ");
            String allocationDate = scanner.nextLine();

            try {
                boolean result = service.allocateAsset(assetId, employeeId, allocationDate);
                if (result) {
                    System.out.println("Asset allocated successfully!");
                } else {
                    System.out.println("Failed to allocate asset.");
                }
            } catch (AssetNotFoundException | EmployeeNotFoundException | AssetAlreadyAllocatedException e) {
                System.out.println("Error: " + e.getMessage());
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void deallocateAsset() {
        try {
            System.out.println("\n----- Deallocate Asset -----");

            System.out.print("Enter asset ID: ");
            int assetId = Integer.parseInt(scanner.nextLine());

            System.out.print("Enter employee ID: ");
            int employeeId = Integer.parseInt(scanner.nextLine());

            System.out.print("Enter return date (yyyy-MM-dd): ");
            String returnDate = scanner.nextLine();

            try {
                boolean result = service.deallocateAsset(assetId, employeeId, returnDate);
                if (result) {
                    System.out.println("Asset deallocated successfully!");
                } else {
                    System.out.println("Failed to deallocate asset. It may not be allocated to the specified employee.");
                }
            } catch (AssetNotFoundException | EmployeeNotFoundException e) {
                System.out.println("Error: " + e.getMessage());
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void performMaintenance() {
        try {
            System.out.println("\n----- Perform Maintenance -----");

            System.out.print("Enter asset ID: ");
            int assetId = Integer.parseInt(scanner.nextLine());

            System.out.print("Enter maintenance date (yyyy-MM-dd): ");
            String maintenanceDate = scanner.nextLine();

            System.out.print("Enter description: ");
            String description = scanner.nextLine();

            System.out.print("Enter cost: ");
            double cost = Double.parseDouble(scanner.nextLine());

            try {
                boolean result = service.performMaintenance(assetId, maintenanceDate, description, cost);
                if (result) {
                    System.out.println("Maintenance recorded successfully!");
                } else {
                    System.out.println("Failed to record maintenance.");
                }
            } catch (AssetNotFoundException e) {
                System.out.println("Error: " + e.getMessage());
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

}