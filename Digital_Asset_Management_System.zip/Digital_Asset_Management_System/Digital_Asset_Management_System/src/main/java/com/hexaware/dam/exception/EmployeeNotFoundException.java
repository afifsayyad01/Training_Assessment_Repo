package com.hexaware.dam.exception;

public class EmployeeNotFoundException extends Exception {

    public EmployeeNotFoundException() {
        super("Employee ID not found!");
    }

    public EmployeeNotFoundException(String message) {
        super(message);
    }
}