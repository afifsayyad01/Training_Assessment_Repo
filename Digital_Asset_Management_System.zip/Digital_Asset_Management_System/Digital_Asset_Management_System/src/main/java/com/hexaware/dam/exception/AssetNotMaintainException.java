package com.hexaware.dam.exception;

public class AssetNotMaintainException extends Exception {

  public AssetNotMaintainException() {
    super("Asset has not been maintained for 2 years!");
  }

  public AssetNotMaintainException(String message) {
    super(message);
  }
}