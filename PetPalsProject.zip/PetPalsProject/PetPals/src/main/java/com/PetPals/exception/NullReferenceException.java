package com.PetPals.exception;

public class NullReferenceException extends Exception {
    public NullReferenceException(String message) {
        super(message);
    }
}