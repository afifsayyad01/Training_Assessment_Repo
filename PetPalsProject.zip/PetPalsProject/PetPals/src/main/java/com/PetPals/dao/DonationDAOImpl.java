package com.PetPals.dao;

import com.PetPals.entity.CashDonation;
import com.PetPals.entity.ItemDonation;
import com.PetPals.util.DBConnUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DonationDAOImpl implements DonationDAO {

    private Connection conn;

    public DonationDAOImpl(String propertyFilePath) {
        this.conn = DBConnUtil.getConnection(propertyFilePath);
    }

    @Override
    public void addCashDonation(CashDonation donation) {
        try {
            if (donation.getAmount() < 10) {
                throw new IllegalArgumentException("Minimum cash donation is ₹10.");
            }

            String sql = "INSERT INTO donations (donor_name, amount, donation_date, item_type) VALUES (?, ?, ?, NULL)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, donation.getDonorName());
            stmt.setDouble(2, donation.getAmount());
            stmt.setDate(3, java.sql.Date.valueOf(donation.getDonationDate()));

            int rows = stmt.executeUpdate();
            System.out.println(rows > 0 ? "Cash donation recorded." : "Insert failed.");

        } catch (SQLException e) {
            System.out.println("SQL Error in cash donation: " + e.getMessage());
        }
    }

    @Override
    public void addItemDonation(ItemDonation donation) {
        try {
            if (donation.getItemType() == null || donation.getItemType().isEmpty()) {
                throw new IllegalArgumentException("Item type cannot be empty.");
            }

            String sql = "INSERT INTO donations (donor_name, amount, donation_date, item_type) VALUES (?, 0, CURDATE(), ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, donation.getDonorName());
            stmt.setString(2, donation.getItemType());

            int rows = stmt.executeUpdate();
            System.out.println(rows > 0 ? "Item donation recorded." : "Insert failed.");

        } catch (SQLException e) {
            System.out.println("SQL Error in item donation: " + e.getMessage());
        }
    }
}