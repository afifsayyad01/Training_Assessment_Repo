package com.PetPals.entity;

import java.util.ArrayList;
import java.util.List;

public class AdoptionEvent {
    private List<IAdoptable> participants;

    public AdoptionEvent() {
        participants = new ArrayList<>();
    }

    public void registerParticipant(IAdoptable participant) {
        participants.add(participant);
        System.out.println("Participant registered for the adoption event.");
    }

    public void hostEvent() {
        System.out.println("Hosting the Adoption Event...");
        if (participants.isEmpty()) {
            System.out.println("No participants available.");
            return;
        }

        for (IAdoptable participant : participants) {
            participant.adopt();
        }
    }
}
