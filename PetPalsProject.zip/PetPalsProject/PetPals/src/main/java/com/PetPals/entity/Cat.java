package com.PetPals.entity;

public class Cat extends Pet {
    private String catColor;

    // Constructor
    public Cat(String name, int age, String breed, String catColor) {
        super(name, age, breed);
        this.catColor = catColor;
    }

    // Getter and Setter
    public String getCatColor() {
        return catColor;
    }

    public void setCatColor(String catColor) {
        this.catColor = catColor;
    }

    // toString Override
    @Override
    public String toString() {
        return super.toString() + ", Cat Color: " + catColor;
    }
}