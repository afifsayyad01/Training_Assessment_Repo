package com.PetPals.entity;

import java.time.LocalDate;

public class CashDonation extends Donation {
    private LocalDate donationDate;

    public CashDonation(String donorName, double amount, LocalDate donationDate) {
        super(donorName, amount);
        this.donationDate = donationDate;
    }

    public LocalDate getDonationDate() {
        return donationDate;
    }

    public void setDonationDate(LocalDate donationDate) {
        this.donationDate = donationDate;
    }

    @Override
    public void recordDonation() {
        if (amount < 10) {
            throw new IllegalArgumentException("Minimum donation amount must be ₹10.");
        }
        System.out.println("Cash donation recorded: ₹" + amount + " by " + donorName + " on " + donationDate);
    }
}
