package com.PetPals.dao;

import com.PetPals.entity.Pet;
import java.util.List;

public interface PetDAO {
    void addPet(Pet pet);
    void removePet(int petId);
    List<Pet> getAllPets();
    Pet getPetById(int petId);
}


