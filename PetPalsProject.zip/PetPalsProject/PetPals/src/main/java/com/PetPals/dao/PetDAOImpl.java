package com.PetPals.dao;

import com.PetPals.entity.Pet;
import com.PetPals.util.DBConnUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PetDAOImpl implements PetDAO {

    private Connection conn;

    public PetDAOImpl(String propertyFilePath) {
        this.conn = DBConnUtil.getConnection(propertyFilePath);
    }

    @Override
    public void addPet(Pet pet) {
        try {
            String sql = "INSERT INTO pets (name, age, breed, type) VALUES (?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, pet.getName());
            stmt.setInt(2, pet.getAge());
            stmt.setString(3, pet.getBreed());
            stmt.setString(4, (pet instanceof com.PetPals.entity.Dog) ? "Dog" : "Cat");

            int rows = stmt.executeUpdate();
            if (rows > 0) {
                System.out.println("Pet added successfully.");
            }
        } catch (SQLException e) {
            System.out.println("Error adding pet: " + e.getMessage());
        }
    }

    @Override
    public void removePet(int petId) {
        try {
            String sql = "DELETE FROM pets WHERE pet_id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, petId);
            int rows = stmt.executeUpdate();
            if (rows == 0) {
                throw new SQLException("Pet ID not found.");
            } else {
                System.out.println("Pet removed successfully.");
            }
        } catch (SQLException e) {
            System.out.println("Error removing pet: " + e.getMessage());
        }
    }

    @Override
    public List<Pet> getAllPets() {
        List<Pet> pets = new ArrayList<>();
        try {
            String sql = "SELECT * FROM pets";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                Pet pet = new Pet(
                        rs.getString("name"),
                        rs.getInt("age"),
                        rs.getString("breed")
                );
                pets.add(pet);
            }
        } catch (SQLException e) {
            System.out.println("Error fetching pets: " + e.getMessage());
        }
        return pets;
    }

    @Override
    public Pet getPetById(int petId) {
        try {
            String sql = "SELECT * FROM pets WHERE pet_id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, petId);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return new Pet(
                        rs.getString("name"),
                        rs.getInt("age"),
                        rs.getString("breed")
                );
            } else {
                throw new SQLException("Pet ID not found.");
            }

        } catch (SQLException e) {
            System.out.println("Error retrieving pet: " + e.getMessage());
            return null;
        }
    }
}