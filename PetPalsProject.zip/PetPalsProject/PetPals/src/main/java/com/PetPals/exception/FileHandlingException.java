package com.PetPals.exception;

public class FileHandlingException extends Exception {
    public FileHandlingException(String message) {
        super(message);
    }
}