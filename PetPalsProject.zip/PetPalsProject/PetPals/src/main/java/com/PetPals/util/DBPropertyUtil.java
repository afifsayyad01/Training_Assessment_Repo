package com.PetPals.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class DBPropertyUtil {

    public static String getConnectionString(String fileName) {
        Properties props = new Properties();
        try (FileInputStream fis = new FileInputStream(fileName)) {
            props.load(fis);
            return props.getProperty("db.url");
        } catch (IOException e) {
            System.out.println("Error loading database properties: " + e.getMessage());
            return null;
        }
    }
}