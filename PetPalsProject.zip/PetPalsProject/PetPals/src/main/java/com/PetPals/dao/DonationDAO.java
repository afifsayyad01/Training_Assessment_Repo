package com.PetPals.dao;

import com.PetPals.entity.CashDonation;
import com.PetPals.entity.ItemDonation;

public interface DonationDAO {
    void addCashDonation(CashDonation donation);
    void addItemDonation(ItemDonation donation);
}