package com.PetPals.main;

import com.PetPals.dao.DonationDAO;
import com.PetPals.dao.DonationDAOImpl;
import com.PetPals.dao.PetDAO;
import com.PetPals.dao.PetDAOImpl;
import com.PetPals.entity.*;

import java.util.List;
import java.util.Scanner;

public class MainModule {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String dbPropPath = "src/main/resources/db.properties";

        PetDAO petDao = new PetDAOImpl(dbPropPath);
        DonationDAO donationDao = new DonationDAOImpl(dbPropPath);

        while (true) {
            System.out.println("\n===== PetPals - Pet Adoption System =====");
            System.out.println("1. Add Pet");
            System.out.println("2. List All Pets");
            System.out.println("3. Remove Pet by ID");
            System.out.println("4. Get Pet by ID");
            System.out.println("5. Record Donation");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");

            int choice = sc.nextInt();
            sc.nextLine(); // clear buffer

            switch (choice) {
                case 1:
                    System.out.print("Enter Pet Type (Dog/Cat): ");
                    String type = sc.nextLine();

                    System.out.print("Enter Name: ");
                    String name = sc.nextLine();

                    System.out.print("Enter Age: ");
                    int age = sc.nextInt();
                    sc.nextLine();

                    System.out.print("Enter Breed: ");
                    String breed = sc.nextLine();

                    try {
                        Pet pet;
                        if (age <= 0) {
                            throw new IllegalArgumentException("Age must be positive.");
                        }

                        if (type.equalsIgnoreCase("Dog")) {
                            System.out.print("Enter Dog Breed Detail: ");
                            String dogBreed = sc.nextLine();
                            pet = new Dog(name, age, breed, dogBreed);
                        } else {
                            System.out.print("Enter Cat Color: ");
                            String color = sc.nextLine();
                            pet = new Cat(name, age, breed, color);
                        }

                        petDao.addPet(pet);

                    } catch (Exception e) {
                        System.out.println("Error: " + e.getMessage());
                    }
                    break;

                case 2:
                    List<Pet> pets = petDao.getAllPets();
                    if (pets.isEmpty()) {
                        System.out.println("No pets found.");
                    } else {
                        pets.forEach(System.out::println);
                    }
                    break;

                case 3:
                    System.out.print("Enter Pet ID to remove: ");
                    int delId = sc.nextInt();
                    sc.nextLine();
                    petDao.removePet(delId);
                    break;

                case 4:
                    System.out.print("Enter Pet ID: ");
                    int searchId = sc.nextInt();
                    sc.nextLine();
                    Pet pet = petDao.getPetById(searchId);
                    if (pet != null) {
                        System.out.println("Pet Found: " + pet);
                    }
                    break;

                case 5:
                    System.out.print("Enter Donor Name: ");
                    String donorName = sc.nextLine();

                    System.out.print("Donation Type (Cash/Item): ");
                    String donationType = sc.nextLine();

                    if (donationType.equalsIgnoreCase("Cash")) {
                        System.out.print("Enter Amount (Minimum ₹10): ");
                        double amount = sc.nextDouble();
                        sc.nextLine();

                        try {
                            CashDonation cash = new CashDonation(donorName, amount, java.time.LocalDate.now());
                            donationDao.addCashDonation(cash);
                        } catch (Exception e) {
                            System.out.println("Error: " + e.getMessage());
                        }

                    } else {
                        System.out.print("Enter Item Type (e.g., food, blanket): ");
                        String item = sc.nextLine();

                        try {
                            ItemDonation itemDonation = new ItemDonation(donorName, item);
                            donationDao.addItemDonation(itemDonation);
                        } catch (Exception e) {
                            System.out.println("Error: " + e.getMessage());
                        }
                    }
                    break;

                case 6:
                    System.out.println("Exiting... Thank you for using PetPals!");
                    sc.close();
                    System.exit(0);

                default:
                    System.out.println("Invalid choice. Please enter a valid option.");
            }
        }
    }
}
