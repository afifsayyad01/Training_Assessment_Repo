package com.PetPals.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnUtil {

    public static Connection getConnection(String propertyFilePath) {
        String url = DBPropertyUtil.getConnectionString(propertyFilePath);
        try {
            return DriverManager.getConnection(url);
        } catch (SQLException e) {
            System.out.println("Failed to connect to database: " + e.getMessage());
            return null;
        }
    }
}