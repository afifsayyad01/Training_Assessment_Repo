package com.PetPals.entity;

import java.util.ArrayList;
import java.util.List;

public class PetShelter {
    private List<Pet> availablePets;

    public PetShelter() {
        availablePets = new ArrayList<>();
    }

    public void addPet(Pet pet) {
        availablePets.add(pet);
        System.out.println("Pet added successfully: " + pet.getName());
    }

    public void removePet(Pet pet) {
        if (availablePets.contains(pet)) {
            availablePets.remove(pet);
            System.out.println("Pet removed successfully: " + pet.getName());
        } else {
            System.out.println("Pet not found in the shelter.");
        }
    }

    public void listAvailablePets() {
        if (availablePets.isEmpty()) {
            System.out.println("No pets available for adoption.");
            return;
        }
        System.out.println("Available Pets for Adoption:");
        for (Pet pet : availablePets) {
            System.out.println(pet);
        }
    }

    public List<Pet> getAvailablePets() {
        return availablePets;
    }
}