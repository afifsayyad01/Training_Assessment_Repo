package com.PetPals.entity;

public interface IAdoptable {
    void adopt();
}