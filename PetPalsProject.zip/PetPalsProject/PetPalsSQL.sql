create database PetPalsProject;
use PetPalsProject;

CREATE TABLE adoption_events (
    event_id INT AUTO_INCREMENT PRIMARY KEY,
    event_name VARCHAR(100),
    event_date DATE
);


CREATE TABLE participants (
    participant_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    event_id INT,
    FOREIGN KEY (event_id) REFERENCES adoption_events(event_id)
);


CREATE TABLE pets (
    pet_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50),
    age INT,
    breed VARCHAR(50),
    type VARCHAR(10) -- 'Dog' or 'Cat'
);


CREATE TABLE donations (
    donation_id INT AUTO_INCREMENT PRIMARY KEY,
    donor_name VARCHAR(100),
    amount DECIMAL(10, 2),
    donation_date DATE,
    item_type VARCHAR(50) -- NULL if cash donation
);


INSERT INTO adoption_events (event_name, event_date) VALUES
('Winter Pet Fest', '2025-01-15'),
('Pune Adoption Drive', '2025-01-22'),
('Love a Pet Day', '2025-02-10'),
('Mumbai Mega Adoption', '2025-02-18'),
('Delhi Shelter Week', '2025-03-05'),
('Spring Paw Fest', '2025-03-25'),
('Pet Connect Nashik', '2025-04-05'),
('Hyderabad Pet Carnival', '2025-04-15'),
('Summer Rescue Camp', '2025-05-01'),
('Chennai Furry Friends', '2025-05-12');


INSERT INTO participants (name, event_id) VALUES
('Arjun Deshmukh', 1),
('Divya Verma', 2),
('Rakesh Nair', 3),
('Aisha Khan', 4),
('Kabir Salunkhe', 5),
('Poonam Rathi', 6),
('Sohail Baig', 7),
('Rekha Ghosh', 8),
('Yashika Dey', 9),
('Kunal Joshi', 10);


INSERT INTO pets (name, age, breed, type) VALUES
('Sheru', 3, 'Labrador', 'Dog'),
('Tommy', 2, 'Beagle', 'Dog'),
('Simba', 4, 'Golden Retriever', 'Dog'),
('Rani', 1, 'Pomeranian', 'Dog'),
('Moti', 5, 'Indie', 'Dog'),
('Misty', 2, 'Persian', 'Cat'),
('Piku', 1, 'Siamese', 'Cat'),
('Golu', 3, 'Maine Coon', 'Cat'),
('Snowy', 4, 'Ragdoll', 'Cat'),
('Chintu', 2, 'Bengal', 'Cat');


INSERT INTO donations (donor_name, amount, donation_date, item_type) VALUES
('Aarav Mehta', 1000.00, '2024-12-01', NULL),
('Simran Joshi', 1500.00, '2024-12-02', NULL),
('Rahul Kulkarni', 700.00, '2024-12-03', NULL),
('Sneha Patil', 0.00, '2024-12-04', 'Pet Food'),
('Karan Malhotra', 0.00, '2024-12-05', 'Blankets'),
('Priya Iyer', 250.00, '2024-12-06', NULL),
('Aniket Sharma', 0.00, '2024-12-07', 'Toys'),
('Neha Gupta', 2000.00, '2024-12-08', NULL),
('Ravi Shinde', 0.00, '2024-12-09', 'Medicine'),
('Meera Das', 0.00, '2024-12-10', 'Cat Food');