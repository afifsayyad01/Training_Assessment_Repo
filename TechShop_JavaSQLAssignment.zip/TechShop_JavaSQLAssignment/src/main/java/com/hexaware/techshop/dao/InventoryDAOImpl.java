package com.hexaware.techshop.dao;

import com.hexaware.techshop.entity.Inventory;
import com.hexaware.techshop.entity.Products;
import com.hexaware.techshop.exception.InsufficientStockException;
import com.hexaware.techshop.exception.InventoryNotFoundException;
import com.hexaware.techshop.exception.ProductNotFoundException;
import com.hexaware.techshop.util.DBConnUtil;
import com.hexaware.techshop.util.DBpropertyUtil;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public class InventoryDAOImpl implements InventoryDAO {
    private Connection connection;
    private ProductDAO productDAO;

    public InventoryDAOImpl() {
        Properties props = DBpropertyUtil.getPropertyObject("db.properties");
        connection = DBConnUtil.getConnection(props);
        productDAO = new ProductDAOImpl();
    }

    @Override
    public boolean addInventory(Inventory inventory) throws ProductNotFoundException {
        // Verify product exists
        Products product = productDAO.getProductById(inventory.getProduct().getProductID());

        String query = "INSERT INTO Inventory (ProductID, QuantityInStock, LastStockUpdate) VALUES (?, ?, ?)";
        try (PreparedStatement pstmt = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {
            pstmt.setInt(1, product.getProductID());
            pstmt.setInt(2, inventory.getQuantityInStock());
            pstmt.setDate(3, Date.valueOf(inventory.getLastStockUpdate()));

            int rowsAffected = pstmt.executeUpdate();

            if (rowsAffected > 0) {
                ResultSet rs = pstmt.getGeneratedKeys();
                if (rs.next()) {
                    inventory.setInventoryID(rs.getInt(1));
                }
                return true;
            }
            return false;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean updateInventory(Inventory inventory) throws InventoryNotFoundException {
        // Check if inventory exists
        getInventoryById(inventory.getInventoryID());

        String query = "UPDATE Inventory SET ProductID=?, QuantityInStock=?, LastStockUpdate=? WHERE InventoryID=?";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, inventory.getProduct().getProductID());
            pstmt.setInt(2, inventory.getQuantityInStock());
            pstmt.setDate(3, Date.valueOf(inventory.getLastStockUpdate()));
            pstmt.setInt(4, inventory.getInventoryID());

            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean deleteInventory(int inventoryID) throws InventoryNotFoundException {
        // Check if inventory exists
        getInventoryById(inventoryID);

        String query = "DELETE FROM Inventory WHERE InventoryID=?";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, inventoryID);

            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public Inventory getInventoryById(int inventoryID) throws InventoryNotFoundException {
        String query = "SELECT * FROM Inventory WHERE InventoryID=?";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, inventoryID);

            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                Inventory inventory = new Inventory(101, 50);
                inventory.setInventoryID(rs.getInt("InventoryID"));

                try {
                    // Get the product for this inventory
                    Products product = productDAO.getProductById(rs.getInt("ProductID"));
                    inventory.setProduct(product);

                    inventory.setQuantityInStock(rs.getInt("QuantityInStock"));
                    inventory.setLastStockUpdate(rs.getDate("LastStockUpdate").toLocalDate());

                    return inventory;
                } catch (ProductNotFoundException e) {
                    throw new InventoryNotFoundException("Related product not found for inventory with ID " + inventoryID);
                }
            } else {
                throw new InventoryNotFoundException("Inventory with ID " + inventoryID + " not found");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new InventoryNotFoundException("Error retrieving inventory: " + e.getMessage());
        }
    }

    @Override
    public Inventory getInventoryByProduct(int productID) throws ProductNotFoundException, InventoryNotFoundException {
        // Verify product exists
        productDAO.getProductById(productID);

        String query = "SELECT * FROM Inventory WHERE ProductID=?";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, productID);

            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                Inventory inventory = new Inventory(101, 50);
                inventory.setInventoryID(rs.getInt("InventoryID"));

                // Get the product
                Products product = productDAO.getProductById(productID);
                inventory.setProduct(product);

                inventory.setQuantityInStock(rs.getInt("QuantityInStock"));
                inventory.setLastStockUpdate(rs.getDate("LastStockUpdate").toLocalDate());

                return inventory;
            } else {
                throw new InventoryNotFoundException("Inventory for product with ID " + productID + " not found");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new InventoryNotFoundException("Error retrieving inventory: " + e.getMessage());
        }
    }

    @Override
    public List<Inventory> getAllInventory() {
        List<Inventory> inventoryList = new ArrayList<>();
        String query = "SELECT * FROM Inventory";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                Inventory inventory = new Inventory(101, 50);
                inventory.setInventoryID(rs.getInt("InventoryID"));

                try {
                    // Get the product for this inventory
                    Products product = productDAO.getProductById(rs.getInt("ProductID"));
                    inventory.setProduct(product);

                    inventory.setQuantityInStock(rs.getInt("QuantityInStock"));
                    inventory.setLastStockUpdate(rs.getDate("LastStockUpdate").toLocalDate());

                    inventoryList.add(inventory);
                } catch (ProductNotFoundException e) {
                    // Skip this inventory if product not found
                    e.printStackTrace();
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return inventoryList;
    }

    @Override
    public boolean updateStock(int productID, int quantity) throws ProductNotFoundException, InventoryNotFoundException {
        // Verify product exists
        productDAO.getProductById(productID);

        try {
            // Check if inventory entry exists for this product
            Inventory inventory = getInventoryByProduct(productID);

            // Update existing inventory
            inventory.setQuantityInStock(quantity);
            inventory.setLastStockUpdate(LocalDate.now());

            return updateInventory(inventory);
        } catch (InventoryNotFoundException e) {
            // Create new inventory entry if not exists
            Products product = productDAO.getProductById(productID);
            Inventory newInventory = new Inventory(101, 50);
            newInventory.setProduct(product);
            newInventory.setQuantityInStock(quantity);
            newInventory.setLastStockUpdate(LocalDate.now());

            return addInventory(newInventory);
        }
    }

    @Override
    public boolean reduceStock(int productID, int quantity) throws ProductNotFoundException, InventoryNotFoundException, InsufficientStockException {
        // Verify product exists
        productDAO.getProductById(productID);

        // Get current inventory
        Inventory inventory = getInventoryByProduct(productID);

        // Check if enough stock is available
        if (inventory.getQuantityInStock() < quantity) {
            throw new InsufficientStockException("Insufficient stock for product " + productID +
                    ". Available: " + inventory.getQuantityInStock() + ", Requested: " + quantity);
        }

        // Reduce stock
        inventory.setQuantityInStock(inventory.getQuantityInStock() - quantity);
        inventory.setLastStockUpdate(LocalDate.now());

        return updateInventory(inventory);
    }

    @Override
    public List<Inventory> getLowStockProducts(int threshold) {
        List<Inventory> lowStockList = new ArrayList<>();
        String query = "SELECT * FROM Inventory WHERE QuantityInStock < ?";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, threshold);

            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                Inventory inventory = new Inventory(101, 50);
                inventory.setInventoryID(rs.getInt("InventoryID"));

                try {
                    // Get the product for this inventory
                    Products product = productDAO.getProductById(rs.getInt("ProductID"));
                    inventory.setProduct(product);

                    inventory.setQuantityInStock(rs.getInt("QuantityInStock"));
                    inventory.setLastStockUpdate(rs.getDate("LastStockUpdate").toLocalDate());

                    lowStockList.add(inventory);
                } catch (ProductNotFoundException e) {
                    // Skip this inventory if product not found
                    e.printStackTrace();
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lowStockList;
    }
}