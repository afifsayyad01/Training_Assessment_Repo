package com.hexaware.techshop.entity;

public class Products {
    private int productID;
    private String productName;
    private String description;
    private double price;

    // Default constructor
    public Products() {
    }

    // Parameterized constructor
    public Products(int productID, String productName, String description, double price) {
        this.productID = productID;
        this.productName = productName;
        this.description = description;
        this.price = price;
    }

    // Getters and setters
    public int getProductID() {
        return productID;
    }

    public void setProductID(int productID) {
        this.productID = productID;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        if (productName == null || productName.trim().isEmpty()) {
            throw new IllegalArgumentException("Product name cannot be empty");
        }
        this.productName = productName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        if (price < 0) {
            throw new IllegalArgumentException("Price cannot be negative");
        }
        this.price = price;
    }

    // Methods as specified in the assignment
    public void getProductDetails() {
        System.out.println("Product ID: " + productID);
        System.out.println("Name: " + productName);
        System.out.println("Description: " + description);
        System.out.println("Price: $" + price);
    }

    public void updateProductInfo(String description, double price) {
        this.description = description;
        if (price < 0) {
            throw new IllegalArgumentException("Price cannot be negative");
        }
        this.price = price;
    }

    public boolean isProductInStock() {
        // Implementation will be done with database connectivity and Inventory class
        return false;
    }

    @Override
    public String toString() {
        return "Product [ID=" + productID + ", Name=" + productName +
                ", Description=" + description + ", Price=$" + price + "]";
    }

    public Object getProductId() {
        return null;
    }
}