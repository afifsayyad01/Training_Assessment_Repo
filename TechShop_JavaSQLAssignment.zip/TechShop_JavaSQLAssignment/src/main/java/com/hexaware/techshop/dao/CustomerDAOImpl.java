package com.hexaware.techshop.dao;

import com.hexaware.techshop.entity.Customers;
import com.hexaware.techshop.exception.CustomerNotFoundException;
import com.hexaware.techshop.util.DBConnUtil;
import com.hexaware.techshop.util.DBpropertyUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public class CustomerDAOImpl implements CustomerDAO {
    private Connection connection;

    public CustomerDAOImpl() {
        Properties props = DBpropertyUtil.getPropertyObject("db.properties");
        connection = DBConnUtil.getConnection(props);
    }

    @Override
    public boolean addCustomer(Customers customer) {
        String query = "INSERT INTO Customers (FirstName, LastName, Email, Phone, Address) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(1, customer.getFirstName());
            pstmt.setString(2, customer.getLastName());
            pstmt.setString(3, customer.getEmail());
            pstmt.setString(4, customer.getPhone());
            pstmt.setString(5, customer.getAddress());

            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean updateCustomer(Customers customer) throws CustomerNotFoundException {
        // First check if customer exists
        if (getCustomerById(customer.getCustomerID()) == null) {
            throw new CustomerNotFoundException("Customer with ID " + customer.getCustomerID() + " not found");
        }

        String query = "UPDATE Customers SET FirstName=?, LastName=?, Email=?, Phone=?, Address=? WHERE CustomerID=?";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(1, customer.getFirstName());
            pstmt.setString(2, customer.getLastName());
            pstmt.setString(3, customer.getEmail());
            pstmt.setString(4, customer.getPhone());
            pstmt.setString(5, customer.getAddress());
            pstmt.setInt(6, customer.getCustomerID());

            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean deleteCustomer(int customerID) throws CustomerNotFoundException {
        // First check if customer exists
        if (getCustomerById(customerID) == null) {
            throw new CustomerNotFoundException("Customer with ID " + customerID + " not found");
        }

        String query = "DELETE FROM Customers WHERE CustomerID=?";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, customerID);

            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public Customers getCustomerById(int customerID) throws CustomerNotFoundException {
        String query = "SELECT * FROM Customers WHERE CustomerID=?";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, customerID);

            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                Customers customer = new Customers(201, "Alice Johnson", "alice@example.com", "1234567890");
                customer.setCustomerID(rs.getInt("CustomerID"));
                customer.setFirstName(rs.getString("FirstName"));
                customer.setLastName(rs.getString("LastName"));
                customer.setEmail(rs.getString("Email"));
                customer.setPhone(rs.getString("Phone"));
                customer.setAddress(rs.getString("Address"));
                return customer;
            } else {
                throw new CustomerNotFoundException("Customer with ID " + customerID + " not found");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new CustomerNotFoundException("Error retrieving customer: " + e.getMessage());
        }
    }

    @Override
    public List<Customers> getAllCustomers() {
        List<Customers> customers = new ArrayList<>();
        String query = "SELECT * FROM Customers";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                Customers customer = new Customers(201, "Alice Johnson", "alice@example.com", "1234567890");
                customer.setCustomerID(rs.getInt("CustomerID"));
                customer.setFirstName(rs.getString("FirstName"));
                customer.setLastName(rs.getString("LastName"));
                customer.setEmail(rs.getString("Email"));
                customer.setPhone(rs.getString("Phone"));
                customer.setAddress(rs.getString("Address"));
                customers.add(customer);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return customers;
    }

    @Override
    public int getTotalOrdersByCustomer(int customerID) throws CustomerNotFoundException {
        // First check if customer exists
        if (getCustomerById(customerID) == null) {
            throw new CustomerNotFoundException("Customer with ID " + customerID + " not found");
        }

        String query = "SELECT COUNT(*) AS OrderCount FROM Orders WHERE CustomerID=?";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, customerID);

            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("OrderCount");
            }
            return 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return 0;
        }
    }
}