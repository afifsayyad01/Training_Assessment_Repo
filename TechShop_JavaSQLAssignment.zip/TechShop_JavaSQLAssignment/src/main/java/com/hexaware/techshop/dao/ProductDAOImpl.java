package com.hexaware.techshop.dao;

import com.hexaware.techshop.entity.Products;
import com.hexaware.techshop.exception.ProductNotFoundException;
import com.hexaware.techshop.util.DBConnUtil;
import com.hexaware.techshop.util.DBpropertyUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public class ProductDAOImpl implements ProductDAO {
    private Connection connection;

    public ProductDAOImpl() {
        Properties props = DBpropertyUtil.getPropertyObject("db.properties");
        connection = DBConnUtil.getConnection(props);
    }

    @Override
    public boolean addProduct(Products product) throws SQLException {
        String query = "INSERT INTO Products (ProductName, Description, Price) VALUES (?, ?, ?)";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(1, product.getProductName());
            pstmt.setString(2, product.getDescription());
            pstmt.setDouble(3, product.getPrice());

            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
        }
    }

    @Override
    public boolean updateProduct(Products product) throws ProductNotFoundException {
        return false;
    }

    @Override
    public boolean deleteProduct(int productID) throws ProductNotFoundException {
        return false;
    }

    @Override
    public Products getProductById(int productID) throws ProductNotFoundException {
        return null;
    }

    @Override
    public List<Products> getAllProducts() {
        return List.of();
    }

    @Override
    public List<Products> searchProductsByName(String name) {
        return List.of();
    }

    @Override
    public List<Products> getProductsByPriceRange(double min, double max) {
        return List.of();
    }
}