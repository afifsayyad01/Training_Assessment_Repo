package com.hexaware.techshop.entity;

public class OrderDetails {
    private int orderDetailID;
    private Orders order;  // Composition
    private Products product;  // Composition
    private int quantity;
    private double discount;

    // Default constructor
    public OrderDetails() {
        this.discount = 0.0;
    }

    // Parameterized constructor
    public OrderDetails(int orderDetailID, Orders order, Products product, int quantity) {
        this.orderDetailID = orderDetailID;
        this.order = order;
        this.product = product;
        this.quantity = quantity;
        this.discount = 0.0;
    }

    // Getters and setters
    public int getOrderDetailID() {
        return orderDetailID;
    }

    public void setOrderDetailID(int orderDetailID) {
        this.orderDetailID = orderDetailID;
    }

    public Orders getOrder() {
        return order;
    }

    public void setOrder(Orders order) {
        this.order = order;
    }

    public Products getProduct() {
        return product;
    }

    public void setProduct(Products product) {
        this.product = product;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        if (quantity <= 0) {
            throw new IllegalArgumentException("Quantity must be positive");
        }
        this.quantity = quantity;
    }

    public double getDiscount() {
        return discount;
    }

    public void setDiscount(double discount) {
        if (discount < 0 || discount > 100) {
            throw new IllegalArgumentException("Discount must be between 0 and 100");
        }
        this.discount = discount;
    }

    // Methods as specified in the assignment
    public double calculateSubtotal() {
        double subtotal = product.getPrice() * quantity;
        if (discount > 0) {
            subtotal = subtotal * (1 - discount / 100);
        }
        return subtotal;
    }

    public void getOrderDetailInfo() {
        System.out.println("Order Detail ID: " + orderDetailID);
        System.out.println("Order ID: " + order.getOrderID());
        System.out.println("Product: " + product.getProductName());
        System.out.println("Quantity: " + quantity);
        System.out.println("Unit Price: $" + product.getPrice());
        System.out.println("Discount: " + discount + "%");
        System.out.println("Subtotal: $" + calculateSubtotal());
    }

    public void updateQuantity(int newQuantity) {
        if (newQuantity <= 0) {
            throw new IllegalArgumentException("Quantity must be positive");
        }
        this.quantity = newQuantity;
        System.out.println("Quantity updated to: " + newQuantity);
    }

    public void addDiscount(double discountPercentage) {
        if (discountPercentage < 0 || discountPercentage > 100) {
            throw new IllegalArgumentException("Discount must be between 0 and 100");
        }
        this.discount = discountPercentage;
        System.out.println("Discount added: " + discountPercentage + "%");
    }

    @Override
    public String toString() {
        return "OrderDetail [ID=" + orderDetailID + ", OrderID=" + order.getOrderID() +
                ", Product=" + product.getProductName() + ", Quantity=" + quantity +
                ", Discount=" + discount + "%, Subtotal=$" + calculateSubtotal() + "]";
    }
}