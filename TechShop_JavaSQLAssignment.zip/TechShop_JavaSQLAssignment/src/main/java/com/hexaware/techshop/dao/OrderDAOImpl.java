package com.hexaware.techshop.dao;

import com.hexaware.techshop.entity.Customers;
import com.hexaware.techshop.entity.Orders;
import com.hexaware.techshop.exception.CustomerNotFoundException;
import com.hexaware.techshop.exception.OrderNotFoundException;
import com.hexaware.techshop.util.DBConnUtil;
import com.hexaware.techshop.util.DBpropertyUtil;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public class OrderDAOImpl implements OrderDAO {
    private Connection connection;
    private CustomerDAO customerDAO;

    public OrderDAOImpl() {
        Properties props = DBpropertyUtil.getPropertyObject("db.properties");
        connection = DBConnUtil.getConnection(props);
        customerDAO = new CustomerDAOImpl();
    }

    @Override
    public boolean addOrder(Orders order) throws CustomerNotFoundException {
        // Verify customer exists
        Customers customer = customerDAO.getCustomerById(order.getCustomer().getCustomerID());

        String query = "INSERT INTO Orders (CustomerID, OrderDate, TotalAmount, Status) VALUES (?, ?, ?, ?)";
        try (PreparedStatement pstmt = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {
            pstmt.setInt(1, customer.getCustomerID());
            pstmt.setDate(2, Date.valueOf(order.getOrderDate()));
            pstmt.setDouble(3, order.getTotalAmount());
            pstmt.setString(4, order.getStatus());

            int rowsAffected = pstmt.executeUpdate();

            if (rowsAffected > 0) {
                ResultSet rs = pstmt.getGeneratedKeys();
                if (rs.next()) {
                    order.setOrderID(rs.getInt(1));
                }
                return true;
            }
            return false;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean updateOrder(Orders order) throws OrderNotFoundException {
        // Check if order exists
        getOrderById(order.getOrderID());

        String query = "UPDATE Orders SET CustomerID=?, OrderDate=?, TotalAmount=?, Status=? WHERE OrderID=?";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, order.getCustomer().getCustomerID());
            pstmt.setDate(2, Date.valueOf(order.getOrderDate()));
            pstmt.setDouble(3, order.getTotalAmount());
            pstmt.setString(4, order.getStatus());
            pstmt.setInt(5, order.getOrderID());

            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean updateOrderStatus(int orderID, String status) throws OrderNotFoundException {
        // Check if order exists
        getOrderById(orderID);

        String query = "UPDATE Orders SET Status=? WHERE OrderID=?";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(1, status);
            pstmt.setInt(2, orderID);

            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean deleteOrder(int orderID) throws OrderNotFoundException {
        // Check if order exists
        getOrderById(orderID);

        // First delete related order details
        String deleteOrderDetails = "DELETE FROM OrderDetails WHERE OrderID=?";
        try (PreparedStatement pstmt = connection.prepareStatement(deleteOrderDetails)) {
            pstmt.setInt(1, orderID);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }

        // Then delete the order
        String deleteOrder = "DELETE FROM Orders WHERE OrderID=?";
        try (PreparedStatement pstmt = connection.prepareStatement(deleteOrder)) {
            pstmt.setInt(1, orderID);

            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public Orders getOrderById(int orderID) throws OrderNotFoundException {
        String query = "SELECT * FROM Orders WHERE OrderID=?";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, orderID);

            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                Orders order = new Orders();
                order.setOrderID(rs.getInt("OrderID"));

                // Get the customer for this order
                try {
                    Customers customer = customerDAO.getCustomerById(rs.getInt("CustomerID"));
                    order.setCustomer(customer);
                } catch (CustomerNotFoundException e) {
                    // If customer not found, create a placeholder
                    Customers placeholder = new Customers(201, "Alice Johnson", "alice@example.com", "1234567890");
                    placeholder.setCustomerID(rs.getInt("CustomerID"));
                    placeholder.setFirstName("Unknown");
                    placeholder.setLastName("Customer");
                    order.setCustomer(placeholder);
                }

                order.setOrderDate(rs.getDate("OrderDate").toLocalDate());
                order.setTotalAmount(rs.getDouble("TotalAmount"));
                order.setStatus(rs.getString("Status"));

                return order;
            } else {
                throw new OrderNotFoundException("Order with ID " + orderID + " not found");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new OrderNotFoundException("Error retrieving order: " + e.getMessage());
        }
    }

    @Override
    public List<Orders> getAllOrders() {
        List<Orders> orders = new ArrayList<>();
        String query = "SELECT * FROM Orders";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                Orders order = new Orders();
                order.setOrderID(rs.getInt("OrderID"));

                // Get the customer for this order
                try {
                    Customers customer = customerDAO.getCustomerById(rs.getInt("CustomerID"));
                    order.setCustomer(customer);
                } catch (CustomerNotFoundException e) {
                    // If customer not found, create a placeholder
                    Customers placeholder = new Customers(201, "Alice Johnson", "alice@example.com", "1234567890");
                    placeholder.setCustomerID(rs.getInt("CustomerID"));
                    placeholder.setFirstName("Unknown");
                    placeholder.setLastName("Customer");
                    order.setCustomer(placeholder);
                }

                order.setOrderDate(rs.getDate("OrderDate").toLocalDate());
                order.setTotalAmount(rs.getDouble("TotalAmount"));
                order.setStatus(rs.getString("Status"));

                orders.add(order);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return orders;
    }

    @Override
    public List<Orders> getOrdersByCustomer(int customerID) throws CustomerNotFoundException {
        // Verify customer exists
        customerDAO.getCustomerById(customerID);

        List<Orders> orders = new ArrayList<>();
        String query = "SELECT * FROM Orders WHERE CustomerID=?";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, customerID);

            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                Orders order = new Orders();
                order.setOrderID(rs.getInt("OrderID"));

                // Get the customer
                Customers customer = customerDAO.getCustomerById(customerID);
                order.setCustomer(customer);

                order.setOrderDate(rs.getDate("OrderDate").toLocalDate());
                order.setTotalAmount(rs.getDouble("TotalAmount"));
                order.setStatus(rs.getString("Status"));

                orders.add(order);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return orders;
    }

    @Override
    public List<Orders> getOrdersByDateRange(LocalDate startDate, LocalDate endDate) {
        List<Orders> orders = new ArrayList<>();
        String query = "SELECT * FROM Orders WHERE OrderDate BETWEEN ? AND ?";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setDate(1, Date.valueOf(startDate));
            pstmt.setDate(2, Date.valueOf(endDate));

            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                Orders order = new Orders();
                order.setOrderID(rs.getInt("OrderID"));

                // Get the customer for this order
                try {
                    Customers customer = customerDAO.getCustomerById(rs.getInt("CustomerID"));
                    order.setCustomer(customer);
                } catch (CustomerNotFoundException e) {
                    // If customer not found, create a placeholder
                    Customers placeholder = new Customers(201, "Alice Johnson", "alice@example.com", "1234567890");
                    placeholder.setCustomerID(rs.getInt("CustomerID"));
                    placeholder.setFirstName("Unknown");
                    placeholder.setLastName("Customer");
                    order.setCustomer(placeholder);
                }

                order.setOrderDate(rs.getDate("OrderDate").toLocalDate());
                order.setTotalAmount(rs.getDouble("TotalAmount"));
                order.setStatus(rs.getString("Status"));

                orders.add(order);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return orders;
    }

    @Override
    public double calculateTotalAmount(int orderID) throws OrderNotFoundException {
        // Check if order exists
        getOrderById(orderID);

        String query = "SELECT SUM(od.Quantity * p.Price) AS TotalAmount " +
                "FROM OrderDetails od " +
                "JOIN Products p ON od.ProductID = p.ProductID " +
                "WHERE od.OrderID = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, orderID);

            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getDouble("TotalAmount");
            }
            return 0.0;
        } catch (SQLException e) {
            e.printStackTrace();
            return 0.0;
        }
    }
}