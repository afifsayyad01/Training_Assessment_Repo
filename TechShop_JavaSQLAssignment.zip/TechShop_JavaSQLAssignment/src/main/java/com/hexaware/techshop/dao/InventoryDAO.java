package com.hexaware.techshop.dao;

import com.hexaware.techshop.entity.Inventory;
import com.hexaware.techshop.exception.InsufficientStockException;
import com.hexaware.techshop.exception.InventoryNotFoundException;
import com.hexaware.techshop.exception.ProductNotFoundException;

import java.util.List;

public interface InventoryDAO {
    boolean addInventory(Inventory inventory) throws ProductNotFoundException;
    boolean updateInventory(Inventory inventory) throws InventoryNotFoundException;
    boolean deleteInventory(int inventoryID) throws InventoryNotFoundException;
    Inventory getInventoryById(int inventoryID) throws InventoryNotFoundException;
    Inventory getInventoryByProduct(int productID) throws ProductNotFoundException, InventoryNotFoundException;
    List<Inventory> getAllInventory();
    boolean updateStock(int productID, int quantity) throws ProductNotFoundException, InventoryNotFoundException;
    boolean reduceStock(int productID, int quantity) throws ProductNotFoundException, InventoryNotFoundException, InsufficientStockException;
    List<Inventory> getLowStockProducts(int threshold);
}