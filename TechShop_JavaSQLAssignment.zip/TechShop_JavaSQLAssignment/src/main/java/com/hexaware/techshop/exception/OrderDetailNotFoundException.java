package com.hexaware.techshop.exception;

public class OrderDetailNotFoundException extends Exception {
    public OrderDetailNotFoundException(String message) {
        super(message);
    }
}
