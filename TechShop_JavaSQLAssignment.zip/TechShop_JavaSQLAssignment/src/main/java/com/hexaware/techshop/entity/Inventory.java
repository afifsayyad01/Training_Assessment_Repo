package com.hexaware.techshop.entity;

import java.time.LocalDate;

public class Inventory {
    private int inventoryID;
    private Products product;  // Composition
    private int quantityInStock;
    private LocalDate lastStockUpdate;

    // Default constructor
    public Inventory(int i, int i1) {
        this.lastStockUpdate = LocalDate.now();
    }

    // Parameterized constructor
    public Inventory(int inventoryID, Products product, int quantityInStock) {
        this.inventoryID = inventoryID;
        this.product = product;
        this.quantityInStock = quantityInStock;
        this.lastStockUpdate = LocalDate.now();
    }

    // Getters and setters
    public int getInventoryID() {
        return inventoryID;
    }

    public void setInventoryID(int inventoryID) {
        this.inventoryID = inventoryID;
    }

    public Products getProduct() {
        return product;
    }

    public void setProduct(Products product) {
        this.product = product;
    }

    public int getQuantityInStock() {
        return quantityInStock;
    }

    public void setQuantityInStock(int quantityInStock) {
        if (quantityInStock < 0) {
            throw new IllegalArgumentException("Quantity in stock cannot be negative");
        }
        this.quantityInStock = quantityInStock;
        this.lastStockUpdate = LocalDate.now();
    }

    public LocalDate getLastStockUpdate() {
        return lastStockUpdate;
    }

    public void setLastStockUpdate(LocalDate lastStockUpdate) {
        this.lastStockUpdate = lastStockUpdate;
    }

    // Methods as specified in the assignment
    public void addToInventory(int quantity) {
        if (quantity <= 0) {
            throw new IllegalArgumentException("Quantity to add must be positive");
        }
        this.quantityInStock += quantity;
        this.lastStockUpdate = LocalDate.now();
        System.out.println("Added " + quantity + " units to inventory. New stock: " + quantityInStock);
    }

    public void removeFromInventory(int quantity) throws Exception {
        if (quantity <= 0) {
            throw new IllegalArgumentException("Quantity to remove must be positive");
        }
        if (quantity > quantityInStock) {
            throw new Exception("Insufficient stock. Current stock: " + quantityInStock);
        }
        this.quantityInStock -= quantity;
        this.lastStockUpdate = LocalDate.now();
        System.out.println("Removed " + quantity + " units from inventory. New stock: " + quantityInStock);
    }

    public void updateStockQuantity(int newQuantity) {
        if (newQuantity < 0) {
            throw new IllegalArgumentException("Stock quantity cannot be negative");
        }
        this.quantityInStock = newQuantity;
        this.lastStockUpdate = LocalDate.now();
        System.out.println("Stock updated to: " + newQuantity);
    }

    public boolean isProductAvailable(int quantityToCheck) {
        return quantityInStock >= quantityToCheck;
    }

    public double getInventoryValue() {
        return product.getPrice() * quantityInStock;
    }

    public boolean isLowStock(int threshold) {
        return quantityInStock < threshold;
    }

    public boolean isOutOfStock() {
        return quantityInStock == 0;
    }

    @Override
    public String toString() {
        return "Inventory [ID=" + inventoryID + ", Product=" + product.getProductName() +
                ", Quantity=" + quantityInStock + ", Last Updated=" + lastStockUpdate +
                ", Value=$" + getInventoryValue() + "]";
    }
}