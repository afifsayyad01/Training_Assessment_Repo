package com.hexaware.techshop.entity;

import java.time.LocalDate;

public class Orders {
    private int orderID;
    private Customers customer;  // Composition
    private LocalDate orderDate;
    private double totalAmount;
    private String status;  // e.g., "Processing", "Shipped", "Delivered"

    // Default constructor
    public Orders() {
        this.orderDate = LocalDate.now();
        this.status = "Processing";
    }

    // Parameterized constructor
    public Orders(int orderID, Customers customer, LocalDate orderDate, double totalAmount, String status) {
        this.orderID = orderID;
        this.customer = customer;
        this.orderDate = orderDate;
        this.totalAmount = totalAmount;
        this.status = status;
    }

    public Orders(int i, Object customerId, LocalDate now, double v) {
    }

    // Getters and setters
    public int getOrderID() {
        return orderID;
    }

    public void setOrderID(int orderID) {
        this.orderID = orderID;
    }

    public Customers getCustomer() {
        return customer;
    }

    public void setCustomer(Customers customer) {
        this.customer = customer;
    }

    public LocalDate getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(LocalDate orderDate) {
        this.orderDate = orderDate;
    }

    public double getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(double totalAmount) {
        if (totalAmount < 0) {
            throw new IllegalArgumentException("Total amount cannot be negative");
        }
        this.totalAmount = totalAmount;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    // Methods as specified in the assignment
    public double calculateTotalAmount() {
        // Implementation will be done with database connectivity and OrderDetails
        return totalAmount;
    }

    public void getOrderDetails() {
        System.out.println("Order ID: " + orderID);
        System.out.println("Customer: " + customer.getFirstName() + " " + customer.getLastName());
        System.out.println("Order Date: " + orderDate);
        System.out.println("Total Amount: $" + totalAmount);
        System.out.println("Status: " + status);
    }

    public void updateOrderStatus(String newStatus) {
        this.status = newStatus;
        System.out.println("Order status updated to: " + newStatus);
    }

    public void cancelOrder() {
        this.status = "Cancelled";
        System.out.println("Order has been cancelled");
        // Additional logic to adjust stock levels would be implemented here
    }

    @Override
    public String toString() {
        return "Order [ID=" + orderID + ", Customer=" + customer.getFirstName() + " " + customer.getLastName() +
                ", Date=" + orderDate + ", Amount=$" + totalAmount + ", Status=" + status + "]";
    }

    public Object getOrderId() {
        return null;
    }
}