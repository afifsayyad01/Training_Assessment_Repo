package com.hexaware.techshop.dao;

import com.hexaware.techshop.entity.OrderDetails;
import com.hexaware.techshop.entity.Orders;
import com.hexaware.techshop.entity.Products;
import com.hexaware.techshop.exception.OrderDetailNotFoundException;
import com.hexaware.techshop.exception.OrderNotFoundException;
import com.hexaware.techshop.exception.ProductNotFoundException;
import com.hexaware.techshop.util.DBConnUtil;
import com.hexaware.techshop.util.DBpropertyUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public class OrderDetailDAOImpl implements OrderDetailDAO {
    private Connection connection;
    private OrderDAO orderDAO;
    private ProductDAO productDAO;

    public OrderDetailDAOImpl() {
        Properties props = DBpropertyUtil.getPropertyObject("db.properties");
        connection = DBConnUtil.getConnection(props);
        orderDAO = new OrderDAOImpl();
        productDAO = new ProductDAOImpl();
    }

    @Override
    public boolean addOrderDetail(OrderDetails orderDetail) throws OrderNotFoundException, ProductNotFoundException {
        // Verify order and product exist
        Orders order = orderDAO.getOrderById(orderDetail.getOrder().getOrderID());
        Products product = productDAO.getProductById(orderDetail.getProduct().getProductID());

        String query = "INSERT INTO OrderDetails (OrderID, ProductID, Quantity) VALUES (?, ?, ?)";
        try (PreparedStatement pstmt = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {
            pstmt.setInt(1, order.getOrderID());
            pstmt.setInt(2, product.getProductID());
            pstmt.setInt(3, orderDetail.getQuantity());

            int rowsAffected = pstmt.executeUpdate();

            if (rowsAffected > 0) {
                ResultSet rs = pstmt.getGeneratedKeys();
                if (rs.next()) {
                    orderDetail.setOrderDetailID(rs.getInt(1));
                }

                // Update order total amount
                double newTotal = orderDAO.calculateTotalAmount(order.getOrderID());
                order.setTotalAmount(newTotal);
                orderDAO.updateOrder(order);

                return true;
            }
            return false;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean updateOrderDetail(OrderDetails orderDetail) throws OrderDetailNotFoundException {
        // Check if order detail exists
        getOrderDetailById(orderDetail.getOrderDetailID());

        String query = "UPDATE OrderDetails SET OrderID=?, ProductID=?, Quantity=? WHERE OrderDetailID=?";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, orderDetail.getOrder().getOrderID());
            pstmt.setInt(2, orderDetail.getProduct().getProductID());
            pstmt.setInt(3, orderDetail.getQuantity());
            pstmt.setInt(4, orderDetail.getOrderDetailID());

            int rowsAffected = pstmt.executeUpdate();

            if (rowsAffected > 0) {
                // Update order total amount
                try {
                    double newTotal = orderDAO.calculateTotalAmount(orderDetail.getOrder().getOrderID());
                    Orders order = orderDetail.getOrder();
                    order.setTotalAmount(newTotal);
                    orderDAO.updateOrder(order);
                } catch (OrderNotFoundException e) {
                    e.printStackTrace();
                }

                return true;
            }
            return false;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean deleteOrderDetail(int orderDetailID) throws OrderDetailNotFoundException {
        // Check if order detail exists and get the order ID
        OrderDetails orderDetail = getOrderDetailById(orderDetailID);
        int orderID = orderDetail.getOrder().getOrderID();

        String query = "DELETE FROM OrderDetails WHERE OrderDetailID=?";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, orderDetailID);

            int rowsAffected = pstmt.executeUpdate();

            if (rowsAffected > 0) {
                // Update order total amount
                try {
                    double newTotal = orderDAO.calculateTotalAmount(orderID);
                    Orders order = orderDetail.getOrder();
                    order.setTotalAmount(newTotal);
                    orderDAO.updateOrder(order);
                } catch (OrderNotFoundException e) {
                    e.printStackTrace();
                }

                return true;
            }
            return false;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public OrderDetails getOrderDetailById(int orderDetailID) throws OrderDetailNotFoundException {
        String query = "SELECT * FROM OrderDetails WHERE OrderDetailID=?";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, orderDetailID);

            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                OrderDetails orderDetail = new OrderDetails();
                orderDetail.setOrderDetailID(rs.getInt("OrderDetailID"));

                try {
                    // Get the order for this order detail
                    Orders order = orderDAO.getOrderById(rs.getInt("OrderID"));
                    orderDetail.setOrder(order);

                    // Get the product for this order detail
                    Products product = productDAO.getProductById(rs.getInt("ProductID"));
                    orderDetail.setProduct(product);

                    orderDetail.setQuantity(rs.getInt("Quantity"));

                    return orderDetail;
                } catch (OrderNotFoundException | ProductNotFoundException e) {
                    throw new OrderDetailNotFoundException("Related order or product not found for order detail with ID " + orderDetailID);
                }
            } else {
                throw new OrderDetailNotFoundException("Order detail with ID " + orderDetailID + " not found");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new OrderDetailNotFoundException("Error retrieving order detail: " + e.getMessage());
        }
    }

    @Override
    public List<OrderDetails> getOrderDetailsByOrderId(int orderID) throws OrderNotFoundException {
        // Verify order exists
        orderDAO.getOrderById(orderID);

        List<OrderDetails> orderDetails = new ArrayList<>();
        String query = "SELECT * FROM OrderDetails WHERE OrderID=?";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, orderID);

            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                OrderDetails orderDetail = new OrderDetails();
                orderDetail.setOrderDetailID(rs.getInt("OrderDetailID"));

                try {
                    // Get the order
                    Orders order = orderDAO.getOrderById(orderID);
                    orderDetail.setOrder(order);

                    // Get the product
                    Products product = productDAO.getProductById(rs.getInt("ProductID"));
                    orderDetail.setProduct(product);

                    orderDetail.setQuantity(rs.getInt("Quantity"));

                    orderDetails.add(orderDetail);
                } catch (ProductNotFoundException e) {
                    // Skip this order detail if product not found
                    e.printStackTrace();
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return orderDetails;
    }
}