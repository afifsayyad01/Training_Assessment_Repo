package com.hexaware.techshop.exception;

public class IncompleteOrderException extends Exception {
    public IncompleteOrderException(String message) {
        super(message);
    }
}