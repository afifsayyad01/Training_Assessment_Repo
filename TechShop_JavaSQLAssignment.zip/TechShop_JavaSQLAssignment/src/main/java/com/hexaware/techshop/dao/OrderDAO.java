package com.hexaware.techshop.dao;

import com.hexaware.techshop.entity.Orders;
import com.hexaware.techshop.exception.CustomerNotFoundException;
import com.hexaware.techshop.exception.OrderNotFoundException;

import java.time.LocalDate;
import java.util.List;

public interface OrderDAO {
    boolean addOrder(Orders order) throws CustomerNotFoundException;
    boolean updateOrder(Orders order) throws OrderNotFoundException;
    boolean updateOrderStatus(int orderID, String status) throws OrderNotFoundException;
    boolean deleteOrder(int orderID) throws OrderNotFoundException;
    Orders getOrderById(int orderID) throws OrderNotFoundException;
    List<Orders> getAllOrders();
    List<Orders> getOrdersByCustomer(int customerID) throws CustomerNotFoundException;
    List<Orders> getOrdersByDateRange(LocalDate startDate, LocalDate endDate);
    double calculateTotalAmount(int orderID) throws OrderNotFoundException;
}
