package com.hexaware.techshop.dao;

import com.hexaware.techshop.entity.Customers;
import com.hexaware.techshop.exception.CustomerNotFoundException;

import java.util.List;

public interface CustomerDAO {
    boolean addCustomer(Customers customer);
    boolean updateCustomer(Customers customer) throws CustomerNotFoundException;
    boolean deleteCustomer(int customerID) throws CustomerNotFoundException;
    Customers getCustomerById(int customerID) throws CustomerNotFoundException;
    List<Customers> getAllCustomers();
    int getTotalOrdersByCustomer(int customerID) throws CustomerNotFoundException;
}