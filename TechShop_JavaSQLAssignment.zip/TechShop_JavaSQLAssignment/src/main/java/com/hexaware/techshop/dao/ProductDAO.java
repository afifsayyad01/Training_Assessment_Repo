package com.hexaware.techshop.dao;

import com.hexaware.techshop.entity.Products;
import com.hexaware.techshop.exception.ProductNotFoundException;

import java.sql.SQLException;
import java.util.List;

public interface ProductDAO {
    boolean addProduct(Products product) throws SQLException;
    boolean updateProduct(Products product) throws ProductNotFoundException;
    boolean deleteProduct(int productID) throws ProductNotFoundException;
    Products getProductById(int productID) throws ProductNotFoundException;
    List<Products> getAllProducts();
    List<Products> searchProductsByName(String name);
    List<Products> getProductsByPriceRange(double min, double max);
}