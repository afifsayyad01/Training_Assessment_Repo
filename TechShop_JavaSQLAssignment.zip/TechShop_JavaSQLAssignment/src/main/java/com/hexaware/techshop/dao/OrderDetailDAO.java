package com.hexaware.techshop.dao;

import com.hexaware.techshop.entity.OrderDetails;
import com.hexaware.techshop.exception.OrderDetailNotFoundException;
import com.hexaware.techshop.exception.OrderNotFoundException;
import com.hexaware.techshop.exception.ProductNotFoundException;

import java.util.List;

public interface OrderDetailDAO {
    boolean addOrderDetail(OrderDetails orderDetail) throws OrderNotFoundException, ProductNotFoundException;
    boolean updateOrderDetail(OrderDetails orderDetail) throws OrderDetailNotFoundException;
    boolean deleteOrderDetail(int orderDetailID) throws OrderDetailNotFoundException;
    OrderDetails getOrderDetailById(int orderDetailID) throws OrderDetailNotFoundException;
    List<OrderDetails> getOrderDetailsByOrderId(int orderID) throws OrderNotFoundException;
}