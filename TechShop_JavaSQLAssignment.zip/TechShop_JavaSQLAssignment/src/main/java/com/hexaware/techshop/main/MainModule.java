package com.hexaware.techshop.main;

import com.hexaware.techshop.dao.*;
import com.hexaware.techshop.entity.*;
import com.hexaware.techshop.exception.*;

import java.time.LocalDate;

public class MainModule {
    public static void main(String[] args) {
        try {
            // DAO initializations
            ProductDAO productDAO = new ProductDAOImpl();
            InventoryDAO inventoryDAO = new InventoryDAOImpl();
            CustomerDAO customerDAO = new CustomerDAOImpl();
            OrderDAO orderDAO = new OrderDAOImpl();
            OrderDetailDAO orderDetailDAO = new OrderDetailDAOImpl();

            // Step 1: Add a product
            Products product = new Products(101, "Smartphone", "Electronics", 599.99);
            productDAO.addProduct(product);
            System.out.println("Product added: " + product);

            // Step 2: Add inventory for the product
            Inventory inventory = new Inventory(101, 50);
            inventoryDAO.addInventory(inventory);
            System.out.println("Inventory added for product ID 101");

            // Step 3: Add a customer
            Customers customer = new Customers(201, "Alice Johnson", "alice@example.com", "1234567890");
            customerDAO.addCustomer(customer);
            System.out.println("Customer added: " + customer);

            // Step 4: Create an order
            Orders order = new Orders(301, customer.getCustomerId(), LocalDate.now(), 599.99);
            orderDAO.addOrder(order);
            System.out.println("Order created: " + order);

            // Step 5: Add order details
            OrderDetails orderDetail = new OrderDetails(401, order.getOrderId(), product.getProductId(), 1, product.getPrice());
            orderDetailDAO.addOrderDetail(orderDetail);
            System.out.println("Order detail added: " + orderDetail);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
